package com.gcat.hellocloudant.web;

import java.util.ArrayList;

import com.ibm.cloud.cloudant.v1.Cloudant;
import com.ibm.cloud.cloudant.v1.model.AllDocsResult;
import com.ibm.cloud.cloudant.v1.model.PostAllDocsOptions;
import com.ibm.cloud.cloudant.v1.model.ServerInformation;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class WebController {

    @GetMapping("/")
    public String hello(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model) throws Exception {

        String cloudantApiKey = System.getenv("CLOUDANT_APIKEY");
        String cloudantDatabase = System.getenv("CLOUDANT_DATABASE");
        String cloudantAddress = System.getenv("CLOUDANT_ADDRESS");
        String cloudantResponse;

        boolean addressOk = false;
        boolean apiKeyOk = false;
        boolean databaseOk = false;

        if (cloudantAddress != null) {
            model.addAttribute("address", cloudantAddress);
            addressOk = true;
        }
        else {
            model.addAttribute("address", "NOT SET");
        }

        if (cloudantDatabase != null) {
            model.addAttribute("database", cloudantDatabase);
            databaseOk = true;
        }
        else {
            model.addAttribute("database", "NOT SET");
        }

        if (cloudantApiKey != null) {
            model.addAttribute("apikeyset", "true");
            apiKeyOk = true;
        }
        else {
            model.addAttribute("apikeyset", "false");
        }

        // Test connectivity to database if variables are set
        if (apiKeyOk && databaseOk && addressOk) {
            IamAuthenticator authenticator = new IamAuthenticator(cloudantApiKey);
            Cloudant client = new Cloudant(Cloudant.DEFAULT_SERVICE_NAME, authenticator);
            client.setServiceUrl(cloudantAddress);

            // get ServerInformation for Cloudant instance... then convert the data to a String so that Thymeleaf can understand this data
            cloudantResponse = client.getServerInformation().execute().getResult().toString();
        }
        else {
            cloudantResponse = "Could not connect to Cloudant database as none or not all of the required service credentials are present!";
        }
        model.addAttribute("cloudantResponse", cloudantResponse);
        return "greeting";
    }
    
    @GetMapping("/querytest")
    public String getData(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model) throws Exception {

        // Get ENVs needed for application
        String cloudantApiKey = System.getenv("CLOUDANT_APIKEY");
        String cloudantDatabase = System.getenv("CLOUDANT_DATABASE");
        String cloudantAddress = System.getenv("CLOUDANT_ADDRESS");

        if (cloudantApiKey == null || cloudantAddress == null || cloudantDatabase == null) {
            model.addAttribute("errMessage", "Database access error - Cloudant credentials not set as ENVs (required: CLOUDANT_APIKEY, CLOUDANT_DATABASE, CLOUDANT_ADDRESS");
        }
        else {
            IamAuthenticator authenticator = new IamAuthenticator(cloudantApiKey);
            Cloudant client = new Cloudant(Cloudant.DEFAULT_SERVICE_NAME, authenticator);
            client.setServiceUrl(cloudantAddress);
            PostAllDocsOptions docsOptions =
                    new PostAllDocsOptions.Builder()
                            .db(cloudantDatabase)
                            .includeDocs(true)
                            .startkey("abc")
                            .limit(10)
                            .build();

            AllDocsResult cloudantResponse = client.postAllDocs(docsOptions).execute().getResult();
            model.addAttribute("response", cloudantResponse.toString());
        }
        return "cloudantResponse";
    }
}
